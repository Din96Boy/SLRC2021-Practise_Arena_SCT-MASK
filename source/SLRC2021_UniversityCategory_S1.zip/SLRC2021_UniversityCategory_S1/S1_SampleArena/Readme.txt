When you are opening the arena in Webots for the first time, you might get some errors claiming that some files are missing.
This happens due to the address differences between computers and is completely normal.
In that case, go to the relevant node in the nodes tree and give the correct path for the URL field.
All the STL files are in the "solidworks" folder.
