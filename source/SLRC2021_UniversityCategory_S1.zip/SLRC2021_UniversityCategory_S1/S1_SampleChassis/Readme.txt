You can import 3D models into Webots, designed in Solidworks or other 3D designing software, by saving them as .slt files.

For more information, check this video.
https://www.youtube.com/watch?v=8iXKxWKfO04 